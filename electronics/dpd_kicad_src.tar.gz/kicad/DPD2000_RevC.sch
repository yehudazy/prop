EESchema Schematic File Version 4
LIBS:DPD2000_RevC-cache
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
Sheet 1 1
Title "DPD2000 Rev-C - system hierarchy"
Date "2026-09-04"
Rev "C"
Comp "Dual Proportional Detector PHA"
Comment1 "0-2000 V piezo + 4-stage Cockcroft-Walton; dual ToT/PHA; 0-2000 V normal range"
Comment2 "Engineering Rev-C; verify HV clearances, PT pin mapping and detector parameters before fabrication"
$EndDescr
$Sheet
S 1000 1500 2800 1400
U A455CB1D
F0 "HV_GENERATOR" 50
F1 "01_HV.sch" 50
$EndSheet
$Sheet
S 4500 1300 2600 1800
U 5EE9E164
F0 "AFE_CHANNEL_A" 50
F1 "02_AFE_A.sch" 50
$EndSheet
$Sheet
S 4500 3900 2600 1800
U C05CE1E1
F0 "AFE_CHANNEL_B" 50
F1 "03_AFE_B.sch" 50
$EndSheet
$Sheet
S 8500 1700 3200 2800
U 2BB98E44
F0 "MCU_THRESHOLDS" 50
F1 "04_MCU.sch" 50
$EndSheet
$Sheet
S 8500 5200 3200 1700
U E39C3780
F0 "POWER_REFERENCE" 50
F1 "05_POWER.sch" 50
$EndSheet
Text Notes 1000 7600 0    55   ~ 0
Global nets join sheets: HV_BUS, DET_A, DET_B, SHAPER_A/B, THR_A/B, TTL_A/B, HV_SENSE, HRTIM_HI/LO, +12V, +5VA, +3V3, VCM, GND_A, GND_HV.
Text Notes 1000 7900 0    55   ~ 0
Open this .sch in KiCad Eeschema. KiCad 7/8/9 imports the legacy Eeschema file and converts it to .kicad_sch on first save.
$EndSCHEMATC
