EESchema Schematic File Version 4
LIBS:DPD2000_RevC-cache
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
Sheet 1 1
Title "05 - Low-voltage power/reference"
Date "2026-09-04"
Rev "C"
Comp "Dual Proportional Detector PHA"
Comment1 "0-2000 V piezo + 4-stage Cockcroft-Walton; dual ToT/PHA; 0-2000 V normal range"
Comment2 "Engineering Rev-C; verify HV clearances, PT pin mapping and detector parameters before fabrication"
$EndDescr
$Comp
L CONN2 J5
U 1 1 D57A95E4
P 1000 1700
F 0 "J5" H 1000 1800 50  0000 C CNN
F 1 "12V_IN" H 1000 1600 50  0000 C CNN
	1    1000 1700
	1    0    0    -1
$EndComp
Text GLabel 700 1620 0    45   BiDi ~ 0
+12V
Text GLabel 700 1780 0    45   BiDi ~ 0
GND_A
$Comp
L REG5 U1
U 1 1 12C6F930
P 3000 1700
F 0 "U1" H 3000 1800 50  0000 C CNN
F 1 "TPS62160_BUCK_5V5" H 3000 1600 50  0000 C CNN
	1    3000 1700
	1    0    0    -1
$EndComp
Text GLabel 2600 1580 0    45   BiDi ~ 0
+12V
Text GLabel 2600 1820 0    45   BiDi ~ 0
+3V3
Text GLabel 3000 2070 1    45   BiDi ~ 0
GND_A
Text GLabel 3400 1580 0    45   BiDi ~ 0
5V5_RAW
$Comp
L REG5 U2
U 1 1 B751B2A8
P 5000 1400
F 0 "U2" H 5000 1500 50  0000 C CNN
F 1 "TPS7A2050_LOW_NOISE_LDO" H 5000 1300 50  0000 C CNN
	1    5000 1400
	1    0    0    -1
$EndComp
Text GLabel 4600 1280 0    45   BiDi ~ 0
5V5_RAW
Text GLabel 5400 1280 0    45   BiDi ~ 0
+5VA
Text GLabel 5000 1770 1    45   BiDi ~ 0
GND_A
$Comp
L REG5 U3
U 1 1 E2C1C582
P 5000 2600
F 0 "U3" H 5000 2700 50  0000 C CNN
F 1 "TPS7A2033_LDO" H 5000 2500 50  0000 C CNN
	1    5000 2600
	1    0    0    -1
$EndComp
Text GLabel 4600 2480 0    45   BiDi ~ 0
5V5_RAW
Text GLabel 5400 2480 0    45   BiDi ~ 0
+3V3
Text GLabel 5000 2970 1    45   BiDi ~ 0
GND_A
$Comp
L REF3030 U4
U 1 1 38520016
P 7600 1500
F 0 "U4" H 7600 1600 50  0000 C CNN
F 1 "REF3030_3.000V" H 7600 1400 50  0000 C CNN
	1    7600 1500
	1    0    0    -1
$EndComp
Text GLabel 7250 1400 0    45   BiDi ~ 0
+5VA
Text GLabel 7600 1810 1    45   BiDi ~ 0
GND_A
Text GLabel 7950 1400 0    45   BiDi ~ 0
VREF_3V0
$Comp
L R R1
U 1 1 F7579FE8
P 8500 2100
F 0 "R1" H 8500 2200 50  0000 C CNN
F 1 "10k_0.1%" H 8500 2000 50  0000 C CNN
	1    8500 2100
	1    0    0    -1
$EndComp
$Comp
L R R2
U 1 1 70D4EE51
P 9300 2100
F 0 "R2" H 9300 2200 50  0000 C CNN
F 1 "10k_0.1%" H 9300 2000 50  0000 C CNN
	1    9300 2100
	1    0    0    -1
$EndComp
Text GLabel 8250 2100 0    45   BiDi ~ 0
VREF_3V0
Text GLabel 9550 2100 0    45   BiDi ~ 0
GND_A
Text Label 8900 2100 0    45   ~ 0
VCM_RAW_1V5
$Comp
L OPA810 U5
U 1 1 F3DBB769
P 10800 2100
F 0 "U5" H 10800 2200 50  0000 C CNN
F 1 "OPA810_VCM_BUFFER" H 10800 2000 50  0000 C CNN
	1    10800 2100
	1    0    0    -1
$EndComp
Text GLabel 10380 2000 0    45   BiDi ~ 0
VCM_RAW_1V5
Wire Wire Line
	10380 2200 11220 2100
Text GLabel 10800 1740 3    45   BiDi ~ 0
+5VA
Text GLabel 10800 2460 1    45   BiDi ~ 0
GND_A
Text GLabel 11220 2100 0    45   BiDi ~ 0
VCM
$Comp
L R R0
U 1 1 32700CE7
P 12500 2200
F 0 "R0" H 12500 2300 50  0000 C CNN
F 1 "0R_STAR_GND" H 12500 2100 50  0000 C CNN
	1    12500 2200
	1    0    0    -1
$EndComp
Text GLabel 12250 2200 0    45   BiDi ~ 0
GND_A
Text GLabel 12750 2200 0    45   BiDi ~ 0
GND_HV
Text Notes 1000 4100 0    50   ~ 0
Place buck in power corner. +5VA passes through low-noise LDO and local ferrite/decoupling before CSA/shaper. +3V3 digital and +5VA analog join only through regulator ground return at STAR_GND.
$EndSCHEMATC
