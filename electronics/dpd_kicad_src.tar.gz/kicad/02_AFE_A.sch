EESchema Schematic File Version 4
LIBS:DPD2000_RevC-cache
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
Sheet 1 1
Title "02/03 - Detector A AFE: coupling, protection, CSA, CR-(RC)^2 shaper"
Date "2026-09-04"
Rev "C"
Comp "Dual Proportional Detector PHA"
Comment1 "0-2000 V piezo + 4-stage Cockcroft-Walton; dual ToT/PHA; 0-2000 V normal range"
Comment2 "Engineering Rev-C; verify HV clearances, PT pin mapping and detector parameters before fabrication"
$EndDescr
Text Notes 700 600 0    50   ~ 0
Channel A: detector electrode carries HV and signal. 4.7nF bias filter is upstream of 10M bias resistor on HV sheet; do NOT bypass DET_A directly to ground.
Text GLabel 800 1800 0    45   BiDi ~ 0
DET_A
$Comp
L C C200
U 1 1 23CD918A
P 1800 1800
F 0 "C200" H 1800 1900 50  0000 C CNN
F 1 "1nF_4kV_SIGNAL_COUPLING" H 1800 1700 50  0000 C CNN
	1    1800 1800
	1    0    0    -1
$EndComp
Wire Wire Line
	1050 1800 1560 1800
$Comp
L R R200
U 1 1 BCC8D2EA
P 2800 1800
F 0 "R200" H 2800 1900 50  0000 C CNN
F 1 "470R_SERIES_PROTECTION" H 2800 1700 50  0000 C CNN
	1    2800 1800
	1    0    0    -1
$EndComp
Wire Wire Line
	2040 1800 2550 1800
Text Label 3100 1800 0    45   ~ 0
PROT_A
$Comp
L D D200
U 1 1 BCECD206
P 3500 1400
F 0 "D200" H 3500 1500 50  0000 C CNN
F 1 "BAV199_LOW_LEAK" H 3500 1300 50  0000 C CNN
	1    3500 1400
	1    0    0    -1
$EndComp
Text GLabel 3240 1400 0    45   BiDi ~ 0
GND_A
Wire Wire Line
	3760 1400 3760 1800
$Comp
L D D201
U 1 1 6DAB7B93
P 3500 2200
F 0 "D201" H 3500 2300 50  0000 C CNN
F 1 "BAV199_LOW_LEAK" H 3500 2100 50  0000 C CNN
	1    3500 2200
	1    0    0    -1
$EndComp
Wire Wire Line
	3240 2200 3240 1800
Text GLabel 3760 2200 0    45   BiDi ~ 0
+5VA
$Comp
L OPA810 U20
U 1 1 D8DA14B8
P 4800 1800
F 0 "U20" H 4800 1900 50  0000 C CNN
F 1 "OPA810_CSA" H 4800 1700 50  0000 C CNN
	1    4800 1800
	1    0    0    -1
$EndComp
Wire Wire Line
	3050 1800 4380 1900
Text GLabel 4380 1700 0    45   BiDi ~ 0
VCM
Text GLabel 4800 2160 3    45   BiDi ~ 0
+5VA
Text GLabel 4800 1440 1    45   BiDi ~ 0
GND_A
$Comp
L R R210
U 1 1 5D1BE8FA
P 4800 950
F 0 "R210" H 4800 1050 50  0000 C CNN
F 1 "10M_DEFAULT (47M/22M/4.7M options)" H 4800 850 50  0000 C CNN
	1    4800 950
	1    0    0    -1
$EndComp
$Comp
L C C210
U 1 1 EBACBCFB
P 5800 950
F 0 "C210" H 5800 1050 50  0000 C CNN
F 1 "4.7pF_DEFAULT (1/2.2/10p options)" H 5800 850 50  0000 C CNN
	1    5800 950
	1    0    0    -1
$EndComp
Wire Wire Line
	4550 950 4380 1900
Wire Wire Line
	5050 950 5560 950
Wire Wire Line
	6040 950 5220 1800
Text Label 5350 1800 0    45   ~ 0
CSA_A_OUT
Text Notes 7000 950 0    45   ~ 0
Select matched Cf/Rf pair so decay stays ~47-48 us: 1pF/47M, 2.2pF/22M, 4.7pF/10M, 10pF/4.7M.
Text GLabel 800 3100 0    45   BiDi ~ 0
CAL_A
$Comp
L C C220
U 1 1 7F64622B
P 1800 3100
F 0 "C220" H 1800 3200 50  0000 C CNN
F 1 "1pF_CAL_DNP" H 1800 3000 50  0000 C CNN
	1    1800 3100
	1    0    0    -1
$EndComp
Wire Wire Line
	2040 3100 4200 3100
Wire Wire Line
	4200 3100 4200 1900
$Comp
L C C230
U 1 1 1B07353A
P 6500 1800
F 0 "C230" H 6500 1900 50  0000 C CNN
F 1 "100pF_HP" H 6500 1700 50  0000 C CNN
	1    6500 1800
	1    0    0    -1
$EndComp
Wire Wire Line
	5220 1800 6260 1800
Text Label 6800 1800 0    45   ~ 0
HP_A
$Comp
L R R230
U 1 1 DCCBC4DF
P 7000 2450
F 0 "R230" H 7000 2550 50  0000 C CNN
F 1 "10k_TO_VCM" H 7000 2350 50  0000 C CNN
	1    7000 2450
	1    0    0    -1
$EndComp
Wire Wire Line
	7000 2210 7000 1800
Text GLabel 7250 2450 0    45   BiDi ~ 0
VCM
$Comp
L R R231
U 1 1 7D771508
P 6500 1300
F 0 "R231" H 6500 1400 50  0000 C CNN
F 1 "487k_PZ_PARALLEL" H 6500 1200 50  0000 C CNN
	1    6500 1300
	1    0    0    -1
$EndComp
Wire Wire Line
	6250 1300 6250 1800
Wire Wire Line
	6750 1300 6750 1800
$Comp
L R R232
U 1 1 BFF7FB67
P 7800 1800
F 0 "R232" H 7800 1900 50  0000 C CNN
F 1 "10k" H 7800 1700 50  0000 C CNN
	1    7800 1800
	1    0    0    -1
$EndComp
Wire Wire Line
	7050 1800 7550 1800
$Comp
L C C232
U 1 1 CE81A059
P 8500 2400
F 0 "C232" H 8500 2500 50  0000 C CNN
F 1 "100pF" H 8500 2300 50  0000 C CNN
	1    8500 2400
	1    0    0    -1
$EndComp
Wire Wire Line
	8050 1800 8500 1800
Wire Wire Line
	8500 2160 8500 1800
Text GLabel 8500 2640 1    45   BiDi ~ 0
VCM
$Comp
L OPA2810 U21
U 1 1 DA5B0BE1
P 9800 2050
F 0 "U21" H 9800 2150 50  0000 C CNN
F 1 "OPA2810_DUAL_SHAPER" H 9800 1950 50  0000 C CNN
	1    9800 2050
	1    0    0    -1
$EndComp
Wire Wire Line
	8500 1800 9300 2170
Wire Wire Line
	9300 2310 9000 2310
Wire Wire Line
	9000 2310 9000 2240
Wire Wire Line
	9000 2240 10300 2240
Text GLabel 9800 2510 3    45   BiDi ~ 0
+5VA
Text GLabel 9800 1590 1    45   BiDi ~ 0
GND_A
$Comp
L R R233
U 1 1 897E8F8E
P 11200 2240
F 0 "R233" H 11200 2340 50  0000 C CNN
F 1 "10k" H 11200 2140 50  0000 C CNN
	1    11200 2240
	1    0    0    -1
$EndComp
Wire Wire Line
	10300 2240 10950 2240
$Comp
L C C233
U 1 1 6C91099B
P 11900 2850
F 0 "C233" H 11900 2950 50  0000 C CNN
F 1 "100pF" H 11900 2750 50  0000 C CNN
	1    11900 2850
	1    0    0    -1
$EndComp
Wire Wire Line
	11450 2240 11900 2240
Wire Wire Line
	11900 2610 11900 2240
Text GLabel 11900 3090 1    45   BiDi ~ 0
VCM
Wire Wire Line
	11900 2240 9300 1930
$Comp
L R R234
U 1 1 0AA53CF8
P 9300 3500
F 0 "R234" H 9300 3600 50  0000 C CNN
F 1 "10k_GAIN_G" H 9300 3400 50  0000 C CNN
	1    9300 3500
	1    0    0    -1
$EndComp
Text GLabel 9050 3500 0    45   BiDi ~ 0
VCM
Wire Wire Line
	9550 3500 9550 1790
$Comp
L R R235
U 1 1 0211BEB0
P 10800 3500
F 0 "R235" H 10800 3600 50  0000 C CNN
F 1 "10k_GAIN_F_DEFAULT" H 10800 3400 50  0000 C CNN
	1    10800 3500
	1    0    0    -1
$EndComp
Wire Wire Line
	10550 3500 9550 3500
Wire Wire Line
	11050 3500 10300 1860
Text GLabel 10600 1860 0    45   BiDi ~ 0
SHAPER_A
Text Notes 700 4300 0    48   ~ 0
Default shaping ~1 us, gain x2. Add PCB spark-gap/GDT footprint before the 470R series resistor.  Stuffing options on R/C pads permit ~0.5/1/2/4 us and x1/x2/x5/x10 without putting an analog switch on the CSA summing node.
Text Notes 700 4700 0    48   ~ 0
Single-supply analog: +5VA, baseline VCM=1.50 V. Keep shaped pulse in 0..3.0 V for direct STM32 ADC and 3.3-V comparator compatibility.
$EndSCHEMATC
