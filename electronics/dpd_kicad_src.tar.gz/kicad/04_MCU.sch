EESchema Schematic File Version 4
LIBS:DPD2000_RevC-cache
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
Sheet 1 1
Title "04 - STM32G474, threshold DAC, comparators, ToT capture"
Date "2026-09-04"
Rev "C"
Comp "Dual Proportional Detector PHA"
Comment1 "0-2000 V piezo + 4-stage Cockcroft-Walton; dual ToT/PHA; 0-2000 V normal range"
Comment2 "Engineering Rev-C; verify HV clearances, PT pin mapping and detector parameters before fabrication"
$EndDescr
$Comp
L STM32G474RET6 U50
U 1 1 E51EA793
P 8500 5200
F 0 "U50" H 8500 5300 50  0000 C CNN
F 1 "STM32G474RET6" H 8500 5100 50  0000 C CNN
	1    8500 5200
	1    0    0    -1
$EndComp
Text GLabel 7600 5280 0    45   BiDi ~ 0
TTL_A
Text GLabel 7600 5160 0    45   BiDi ~ 0
TTL_B
Text GLabel 7600 5800 0    45   BiDi ~ 0
SHAPER_A
Text GLabel 7600 5680 0    45   BiDi ~ 0
SHAPER_B
Text GLabel 7600 5560 0    45   BiDi ~ 0
HV_SENSE
Text GLabel 7600 5440 0    45   BiDi ~ 0
HV_SET
Text GLabel 9400 5040 0    45   BiDi ~ 0
HRTIM_HI_CMD
Text GLabel 9400 5160 0    45   BiDi ~ 0
HRTIM_LO_CMD
Text GLabel 9400 4600 0    45   BiDi ~ 0
USB_DM
Text GLabel 9400 4480 0    45   BiDi ~ 0
USB_DP
Text GLabel 9400 4320 0    45   BiDi ~ 0
SWDIO
Text GLabel 9400 4200 0    45   BiDi ~ 0
SWCLK
Text GLabel 9400 5800 0    45   BiDi ~ 0
OVP_OK
Text GLabel 7600 5040 0    45   BiDi ~ 0
HV_SET
Text GLabel 8050 4100 3    45   BiDi ~ 0
+3V3
Text GLabel 8900 4100 3    45   BiDi ~ 0
+3V3
Text GLabel 8050 6300 1    45   BiDi ~ 0
GND_A
Text GLabel 8900 6300 1    45   BiDi ~ 0
GND_A
$Comp
L DAC80502 U40
U 1 1 2E056A32
P 2800 2200
F 0 "U40" H 2800 2300 50  0000 C CNN
F 1 "DAC80502DRX_16BIT" H 2800 2100 50  0000 C CNN
	1    2800 2200
	1    0    0    -1
$EndComp
Text GLabel 2800 1640 3    45   BiDi ~ 0
+3V3
Text GLabel 2800 2760 1    45   BiDi ~ 0
GND_A
Text GLabel 3320 1900 0    45   BiDi ~ 0
DAC_THR_A
Text GLabel 3320 2500 0    45   BiDi ~ 0
DAC_THR_B
Text GLabel 2280 2080 0    45   BiDi ~ 0
DAC_MOSI
Text GLabel 2280 2200 0    45   BiDi ~ 0
DAC_CS
Text GLabel 2280 2320 0    45   BiDi ~ 0
DAC_SCK
Text GLabel 2280 2500 0    45   BiDi ~ 0
GND_A
Text GLabel 2280 1900 0    45   BiDi ~ 0
GND_A
$Comp
L R R410
U 1 1 F1E852B3
P 3800 1900
F 0 "R410" H 3800 2000 50  0000 C CNN
F 1 "10k_THR_A_FILTER" H 3800 1800 50  0000 C CNN
	1    3800 1900
	1    0    0    -1
$EndComp
Text GLabel 3550 1900 0    45   BiDi ~ 0
DAC_THR_A
Text GLabel 4050 1900 0    45   BiDi ~ 0
THR_A
$Comp
L C C410
U 1 1 48A38F82
P 4300 2200
F 0 "C410" H 4300 2300 50  0000 C CNN
F 1 "100n_THR_A" H 4300 2100 50  0000 C CNN
	1    4300 2200
	1    0    0    -1
$EndComp
Text GLabel 4060 2200 0    45   BiDi ~ 0
THR_A
Text GLabel 4540 2200 0    45   BiDi ~ 0
GND_A
$Comp
L R R411
U 1 1 824D0B20
P 3800 2500
F 0 "R411" H 3800 2600 50  0000 C CNN
F 1 "10k_THR_B_FILTER" H 3800 2400 50  0000 C CNN
	1    3800 2500
	1    0    0    -1
$EndComp
Text GLabel 3550 2500 0    45   BiDi ~ 0
DAC_THR_B
Text GLabel 4050 2500 0    45   BiDi ~ 0
THR_B
$Comp
L C C411
U 1 1 4A165A9B
P 4300 2800
F 0 "C411" H 4300 2900 50  0000 C CNN
F 1 "100n_THR_B" H 4300 2700 50  0000 C CNN
	1    4300 2800
	1    0    0    -1
$EndComp
Text GLabel 4060 2800 0    45   BiDi ~ 0
THR_B
Text GLabel 4540 2800 0    45   BiDi ~ 0
GND_A
$Comp
L TLV3502 U41
U 1 1 AF3E8111
P 5200 2500
F 0 "U41" H 5200 2600 50  0000 C CNN
F 1 "TLV3502AID" H 5200 2400 50  0000 C CNN
	1    5200 2500
	1    0    0    -1
$EndComp
Text GLabel 4700 2620 0    45   BiDi ~ 0
SHAPER_A
Text GLabel 4700 2760 0    45   BiDi ~ 0
THR_A
Text GLabel 5700 2690 0    45   BiDi ~ 0
TTL_A
Text GLabel 4700 2380 0    45   BiDi ~ 0
SHAPER_B
Text GLabel 4700 2240 0    45   BiDi ~ 0
THR_B
Text GLabel 5700 2310 0    45   BiDi ~ 0
TTL_B
Text GLabel 5200 2040 3    45   BiDi ~ 0
+3V3
Text GLabel 5200 2960 1    45   BiDi ~ 0
GND_A
Text Notes 3900 3250 0    45   ~ 0
Each shaper feeds comparator through 1k; 680k output-to-+ feedback gives about 4-5mV hysteresis. 47R series at TTL output for edge damping. Threshold DAC has 10k/100n RC per channel.
Text Notes 1000 3900 0    55   ~ 0
TIMING PIN MAP (verified against STM32G474 LQFP64):
Text Notes 1000 4200 0    45   ~ 0
PA0 pin12 / TIM2_CH1 = TTL_A
Text Notes 1000 4450 0    45   ~ 0
PA1 pin13 / TIM2_CH2 = TTL_B (same 32-bit TIM2 counter)
Text Notes 1000 4700 0    45   ~ 0
PC0 pin8 ADC12_IN6 = SHAPER_A
Text Notes 1000 4950 0    45   ~ 0
PC1 pin9 ADC12_IN7 = SHAPER_B
Text Notes 1000 5200 0    45   ~ 0
PC2 pin10 ADC12_IN8 = HV_SENSE
Text Notes 1000 5450 0    45   ~ 0
PA4 pin18 DAC1_OUT1 = HV_SET (0..2.0 V)
Text Notes 1000 5700 0    45   ~ 0
PA8 pin42 / HRTIM1_CHA1 = PT drive HI
Text Notes 1000 5950 0    45   ~ 0
PA9 pin43 / HRTIM1_CHA2 = PT drive LO
Text Notes 1000 6200 0    45   ~ 0
PA5 pin19 SPI1_SCK, PA7 pin21 MOSI, PB0 pin24 DAC_CS
Text Notes 1000 6600 0    50   ~ 0
At 170 MHz, one TIM2 32-bit counter clocks CH1 and CH2 at 5.882 ns/tick. Each input captures both edges; ToT=t_fall-t_rise. Same-counter leading-edge timestamps make anticoincidence subtraction direct and deterministic.
$EndSCHEMATC
